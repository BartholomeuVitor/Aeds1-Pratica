
#include <stdio.h>

int main(int argc, char**argv){

    printf("Um triangulo é constituido por 3 lados\n");
            
        
    
    int a;
    int b;
    int c;
    
   

    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
   
    if ((a+b>c) && (b+c>a) &&(a+c>b)){
        printf("É um triangulo\n");  
    
        if ((a==b) &&(b==c) &&(c==a)) {
            printf("É um triangulo equilatero\n");         
        
        }
        if ((a==b) &&(c > b)&&(c > a)){
            printf("É um triangulo isosceles\n");
                   
        }
        if ((a!=b)&& (b!=c) &&(c!=a)){
            printf("É um triangulo escaleno\n");
            
        }
        
        if ( ( (c*c) ==(a*a)+(b*b)) || ((a*a)==(c*c)+(b*b)) || ( (b*b) ==(a*a) +(c*c) ) ) {
            // 
            printf("É um triangulo retangulo\n");
            
        }
        
    }
     else {
        
        printf("Não é um triangulo\n");
        
     } 
    
    
    return 0;
}
    

 