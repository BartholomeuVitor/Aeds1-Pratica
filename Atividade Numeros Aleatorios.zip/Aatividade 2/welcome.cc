

#include <iostream>
#include <time.h>
#include <fstream>
#include <stdio.h>

using namespace std;

int main(int argc, char**argv) {
    
    srand( time (NULL));
    
    //int altura;
    //cin >> altura;
    //cout << "A altura é: " << altura << endl;
           
            
    
    
    float p = rand()%(230 + 1 - 150) +150 ;
    p = p /100;
    cout << p << endl;
    
    float altura, alturaMaior , alturaMenor ;
    alturaMenor = 250;
    altura = 0;
    alturaMaior = 0;
    int Maiorque2M = 0;
            
    for (int i = 0; i < 1000; i++){
        int alturaAtual = rand ()%(230 + 1 - 150) + 150;
        altura = altura + alturaAtual;
        
        if (alturaMaior < alturaAtual){
            alturaMaior = alturaAtual;
           
        }
        if (alturaMenor > alturaAtual){
            alturaMenor = alturaAtual;
        }
        
        if (alturaAtual > 200 ){
            Maiorque2M++;
            
        }
     
    }
    
    altura = altura / 100;
    cout << altura << endl;
    cout << altura/1000 << endl;
    cout << "A maior altura é: " << alturaMaior/100 << endl;
    cout << "A menor altura é: " << alturaMenor/100 << endl;
    cout << "Porcetagem de pessoas acima de 2metros:" << float(Maiorque2M)/10 << endl;
    
   
   
     
    return 0;
}
